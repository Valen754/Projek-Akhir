<aside class="sidebar" aria-label="Sidebar navigation">
    <a href="../../pages/kasir/kasir.php">
        <button class="active" aria-label="Hot Dishes"><i class="fas fa-utensils"></i></button>
    </a>
    <a href="../../pages/kasir/reservasi_kasir.php">
        <button aria-label="Settings"><i class="fas fa-cog"></i></button>
    </a>
    <a href="../../pages/kasir/notif.php">
        <button aria-label="Notification"><i class="fas fa-bell"></i></button>
    </a>
    <a href="../../pages/kasir/profile.php">
        <button aria-label="User"><i class="fas fa-user"></i></button>
    </a>
    <a href="../../pages/kasir/riwayat_pesanan.php"> <button aria-label="Riwayat Pesanan"><i class="fas fa-history"></i></button>
    </a>
</aside>